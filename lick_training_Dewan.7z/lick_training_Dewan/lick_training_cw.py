'''
Created on 2013_06_06

@author: Admir Resulaj, CW

_________  __      __
\_   ___ \/  \    /  \
/    \  \/\   \/\/   /
\     \____\        /
 \______  / \__/\  /
        \/       \/
'''
# Another change

# a conflicting change....
import voyeur.db as db
from olfactometer_arduino import Olfactometers
from numpy import append, arange, hstack, nan, isnan, copy, negative
from voyeur.monitor import Monitor
from voyeur.protocol import Protocol, TrialParameters, time_stamp
from voyeur.exceptions import SerialException, ProtocolException
from enthought.traits.trait_types import Button
from enthought.traits.api import Int, Str, Array, Instance, HasTraits, Float, Enum, Bool, Range
from enthought.traits.ui.api import View, Group, HGroup, VGroup, Item, spring
from enthought.chaco.api import ArrayPlotData, Plot, VPlotContainer, DataRange1D
from enthought.enable.component_editor import ComponentEditor
from enthought.enable.component import Component
from enthought.traits.ui.editors import ButtonEditor, DefaultOverride
from enthought.pyface.timer.api import Timer, do_after
from enthought.pyface.api import FileDialog, OK
from enthought.chaco.tools.api import PanTool
from enthought.chaco.axis import PlotAxis
from enthought.chaco.scales.api import TimeScale
from enthought.chaco.scales_tick_generator import ScalesTickGenerator
from enthought.chaco.scales.api import CalendarScaleSystem
import Voyeur_utilities
from datetime import datetime
from configobj import ConfigObj

from copy import deepcopy
import random, time, os
from numpy.random import permutation  # # need numpy 1.7 or higher for choice function
from random import choice, randint


from Stimulus import LaserStimulus, LaserTrainStimulus  # OdorStimulus
from range_selections_overlay import RangeSelectionsOverlay

class Lick2Afc(Protocol):
    """Protocol for 2AFC task on a lick-based choice"""

    STREAMSIZE = 5000
    BLOCKSIZE = 24

    SLIDINGWINDOW = 10
    VALVETIMEDELAY = 1500  # amount of time in milliseconds for odor valve to stay on before trial start
    ADAPTINGODORDELAY = 3000
    NITROGEN_1 = 100
    MAXTRIALDURATION = 500  # Maximum trial duration to wait for in seconds
    ARDUINO = 1
    MAXCLEANTIME = 2000
    MAXSNIFFCLEANRUNS = 20

    # Dictionaries for Olfactometer odor vials
    # { valve_index in the olfactometer ==> ("odor name", odor_concentration, odor_valve)}
    olfa1 = {}
    olfa2 = {}
    olfas = ()
    laser_power_table = {}


    stimuli = {
               "Right" : [],
               "Left": [],
               "RightorLeft": []
               }

    # protocol parameters (session parameters for Voyeur)
    mouse = Int(0, label='mouse')
    rig = Str("", label='rig')  # addition of odor field
    stamp = Str(label='stamp')
    session = Int(0, label='session')
    protocol_name = Str(label='protocol')
    enable_blocks = Enum("Blocks", "No Blocks")
    rewards = Int(0, label="Total rewards")
    response_type ='lick'
    protocol_type = Enum('Please Select',
                         'Single port',
                         'Alternate',
                         'Blocks',
                         )
    trial_structure = Enum("Blocks", "Random", "deBias")
    blocksize = Int(10, label="Block size")
    # lick_first = Enum("Lick first for rewards", "Lick independant rewards", label = "Lick dependance")  - THIS IS FOR TREADMILL

    # controller parameters (trial parameters for arduino)
    trialNumber = Int(1, label='Trial')
    trialtype = Enum(("Right", "Left", "RightorLeft"), label="Trial type")
    waterdur = Int(0, label="Water valve 1 duration")
    waterdur2 = Int(0, label="Water valve 2 duration")
    fvdur = Int(0, label="Final valve duration")
    trialdur = Int(0, label="Trial duration")
    interTrialIntervalSeconds = Int(0, label='ITI seconds')
    lickgraceperiod = Int(0, label="Lick grace period")
    sniffmaxdelay = Int(1200, label="Sniff max delay")  # delay for sniff Trigger change
    lasergolatency = Int(0, label="Laser Go Latency")
    fvTrigPhase = Enum("Exhalation onset", "During exhalation", label="FV triggered phase")
    fvTrigPhaseVal = Int(1, label="FV triggered phase")
    laserTrigPhase = Enum("Inhalation", "Exhalation", label="Laser triggered sniff phase")
    laserTrigPhaseVal = Int(0, label="Laser triggered sniff phase")


    # event
    tick = Array
    result = Array
    trialstart = Int(0, label="Trial start time stamp")
    trialend = Int(0, label="Trial end time stamp")
    firstlick = Int(0, label="Time of first lick")
    firstrewardlick = Int(0, label="Time of first reward lick")
    paramsgottime = Int(0, label="Time parameters received time stamp")
    no_sniff = Bool(False, label="Lost sniffing in last trial")
    fvOnTime = Int(0, label="Time of final valve open")
    
    
    # Timers
    elapsed_time_sec = Int(0, label = 'sec:')
    elapsed_time_min = Int(0, label = 'Time since session start - min:')
    trial_time = Int(0, label = 'Time since last response (sec)')

    # streaming data
    iteration = Array
    sniff = Array
    treadmill = Array
    lick1 = Array
    lick2 = Array
    laser = Array


    # internal (recalculated for each trial)
    _mask_timing = 'normal'
    _olfactometer = Instance(Olfactometers)
    _next_trialNumber = Int(0, label='trialNumber')
    _next_trialtype = Enum(("Right", "Left", "RightorLeft"), label="Trial type")
    _last_trialtype = Enum(("Right", "Left", "RightorLeft"), label="Last trial type")
    _equalBlock = True
    # _next_waterdur = Int(0, label="Water reward duration")
    # _next_trialdur = Int(0, label = "Trial duration")
    # _next_lickperiod = Int(0, label = "Lick grace period")
    # _next_fvdur = Int(0, label = "Final valve duration")
    _next_odorconc = Float(0, label="Odor concentration")
    _next_odor = Str("Next odor", label="Odor")  # addition of odor concentration
    _next_trial_start = 0
    _next_stim = Instance(LaserTrainStimulus)
    _wv = Str('1')
    _windowResults = []  # bias correction
    _windowRightResults = []  # bias correction
    _windowSameResults = []
    _righttrials = Array
    _lefttrials = Array
    _corrights = 0
    _corlefts = 0
    _blockRightMoves = 0
    _blockLeftMoves = 0
    _falserights = 0
    _falselefts = 0
    _nomoves = 0
    _bilicks = 0
    _slwcrr = 0  # sliding window correct rights
    _slwcrl = 0  # sliding window correct lefts
    _slwrightvals = []  # values for Right trials for the current sliding window period
    _slwleftvals = []  # values for Left trials for the cur. sliding window period
    _next_odorconc = Float(0)
    _max_rewards = 0
#    _leftResponses = 0 # bias correction - sliding window
#    _rightResponses = 0 # # bias correction - sliding window
#    _sameSideResponses = [] # bias correction - sliding window
#    _oppositeSideResponses = 0 # bias correction - sliding window
    _paramsenttime = float()
    _resultstime = float()
    _laststreamtick = Float(0)
    _lastlickstamp = 0
    _previousendtick = 0
    _inblockcorrect = 0
    _stimindex = int(0)

    _unsyncedtrials = 0
    _first_trial_block = []  # deBias
    _leftstimblock = []
    _rightstimblock = []

    # GUI
    monitor = Instance(object)
    event_plot = Instance(Plot, label="Success Rate")
    stream_plots = Instance(Component)
    stream_plot = Instance(Plot, label="Sniff")
    stream_event_plot = Instance(Plot, label="Events")
    start_button = Button()
    cal_olfa_button = Button()
    start_label = Str('Start')
    cal_olfa_label = Str('Cal Olfa (OFF)')
    pause_button = Button()
    pause_label = Str('Pause')
    save_as_button = Button("Save as")
    olfactory_button = Button()
    olfactory_label = Str('Olfactometer')
    fv_button = Button("Final Valve")
    fv_label = Str("Final Valve (OFF)")
    cal_button1 = Button("Cal Water 1")
    cal_button2 = Button("Cal Water 2")
    water_button1 = Button(label="Water Valve 1")
    water_button2 = Button(label="Water Valve 2")
    clean_button = Button("Clean Valve")
    clean_label = Str("Clean (OFF)")
    laser_select = Enum('Laser 1', 'Laser 2')
    laser_button = Button(label="Select laser")
    laser_labels = ('Laser 1', 'Laser 2')
    laser_amp = Range(low=0, high=5000, value=2000, mode='slider', enter_set=True)
    laser_dur = Int(0, label='Laser pulse dur(ms)')

    session_group = Group(
                        Item('mouse', enabled_when='not monitor.running'),
                        Item('session', enabled_when='not monitor.running'),
                        Item('stamp', style='readonly'),
                        Item('protocol_name', style='readonly'),
                        Item('protocol_type', enabled_when='not monitor.running'),
                        HGroup(Item('trial_structure', enabled_when='not (protocol_type=="Staircasing")'),
                                spring,
                                Item('blocksize', visible_when='trial_structure == "Blocks"',
                                      width=-100, tooltip="Block Size", show_label=False, full_size=False, springy=False, resizable=False)),
                        # Item('lick_first'),
                        Item('rig', enabled_when='not monitor.running'),
                        Item('rewards', style='readonly'),
                        HGroup(Item('elapsed_time_min',style='readonly'),Item('elapsed_time_sec',style = 'readonly'),show_border = False),
                        Item('trial_time',style = 'readonly'),
                        label='Session',
                        show_border=True
                    )


    arduino = VGroup(
        HGroup(
            Item('fv_button',
                 editor=ButtonEditor(
                     style="button", label_value='fv_label'),
                 show_label=False),
            Item('clean_button',
                 editor=ButtonEditor(
                     style="button", label_value='clean_label'),
                 show_label=False),
            VGroup(    Item('water_button1',
                         editor=ButtonEditor(style="button"),
                         show_label=False),
                    Item('water_button2',
                         editor=ButtonEditor(style="button"),
                         show_label=False),
                    ),
            VGroup(Item('cal_button1',
                        editor=ButtonEditor(style="button"),
                        enabled_when='not monitor.recording',
                        show_label=False),
                   Item('cal_button2',
                        editor=ButtonEditor(style="button"),
                        enabled_when='not monitor.recording',
                        show_label=False)
                   ),
            VGroup(Item('waterdur', enabled_when='not monitor.recording'),
                   Item(
                'waterdur2', enabled_when='not monitor.recording')
            )
        ),
        HGroup(
            Item('laser_select', label='Select Laser'),
            Item('laser_button', label='Trig Laser',
                 editor=ButtonEditor(style="button"),
                 show_label=False, enabled_when='not monitor.recording'),
            VGroup(Item('laser_amp', label="Amplitude",  # width = 185,
                        editor=DefaultOverride(high_label='5000(mv)', low_label='0(mv)')),
                   Item('laser_dur'))
        ),
        label="Arduino Control",
        show_border=True
    )

    control = VGroup(
                    HGroup(
                            Item('start_button',
                                    editor=ButtonEditor(label_value='start_label'),
                                    show_label=False),
                            Item('pause_button',
                                    editor=ButtonEditor(label_value='pause_label'),
                                    show_label=False,
                                    enabled_when='monitor.running'),
                            # label = 'Control',
                            show_border=False
                            ),
                    label='Control',
                    show_border=True,
                    )

    current = Group(
                        Item('trialNumber', style='readonly'),
                        Item('interTrialIntervalSeconds'),
                        Item('trialtype'),
                        Item('trialdur'),
                        label='Current Trial',
                        show_border=True
                    )

    next = Group(
                    Item('_next_trialtype'),
                    Item('_next_odor'),
                    Item('_next_odorconc'),  # addition
                    label='Next Trial',
                    show_border=True
                )


    stream = Group (
                        Item('stream_plots', editor=ComponentEditor(), show_label=False, height=300,
                             padding=2),
                        label='Streaming', padding=2,
                        show_border=True,
                    )

    main = View(
                    VGroup(
                            HGroup(control, arduino),
                            HGroup(session_group,
                                    current,
                                    next),
                            stream,
                            show_labels=True,
                    ),
                    title='Lick Trainer',
                    width=930,
                    height=800,
                    x=30,
                    y=70,
                    resizable=True
                )

    def _stream_event_plot_default(self):
        pass

    def _stream_plots_default(self):

        container = VPlotContainer(bgcolor="transparent", fill_padding=False, padding=0)

        # add the streaming plots
        self.stream_plot_data = ArrayPlotData(iteration=self.iteration, sniff=self.sniff, laser=self.laser,treadmill=self.treadmill)
        y_range = DataRange1D(low=-2500, high=2500)
        plot = Plot(self.stream_plot_data, padding=25, padding_top=0, padding_left=60)
        plot.fixed_preferred_size = (100, 100)
        plot.value_range = y_range
        y_axis = plot.y_axis
        y_axis.title = "Signal (mV)"
        # y_axis.tools.append(RightClickTool(y_axis))
        range_in_sec = self.STREAMSIZE / 1000.0
        self.iteration = arange(0.001, range_in_sec + 0.001, 0.001)
        self.sniff = [nan] * len(self.iteration)
        self.treadmill = [nan] *len(self.iteration)
        plot.plot(('iteration', 'sniff'), type='line', color='black', name="Sniff")
        plot.plot(('iteration', 'treadmill'), type = 'line', color = 'green', name ='Treadmill')
        self.stream_plot_data.set_data("iteration", self.iteration)
        self.stream_plot_data.set_data("sniff", self.sniff)
        self.stream_plot_data.set_data("treadmill",self.treadmill)
        bottom_axis = PlotAxis(plot, orientation="bottom",  # mapper=xmapper,
                               # tick_interval = 1,
                    tick_generator=ScalesTickGenerator(scale=TimeScale(milliseconds=1)))
        # TODO: change the axis mapper to be static
        plot.x_axis = bottom_axis
        plot.x_axis.title = "Time"

        self.stream_plot = plot
        laser_plot = plot.plot(("iteration", "laser"), name="Laser", color="blue", line_width=2)[0]
        plot.legend.visible = True
        plot.legend.bgcolor = "transparent"

        # get the sniff plot and add a selection overlay ability to it
        if 'Sniff' in self.stream_plot.plots.keys():
            sniff = self.stream_plot.plots['Sniff'][0]
            rangeselector = (RangeSelectionsOverlay(component=sniff, metadata_name='trials_mask'))
            sniff.overlays.append(rangeselector)
            datasource = getattr(sniff, "index", None)
            datasource.metadata.setdefault("trials_mask", [])
            # mask = [2,3]
            # datasource.metadata['trials_mask'] = mask
            # datasource.metadata_changed = {"sniff": mask}
            # datasource.metadata_changed = {"selection_masks": (500,1500)}
            # print sniff.index.metadata
            # print datasource.metadata_changed
            # sniff.request_redraw()

        self.stream_events_data = ArrayPlotData(iteration=self.iteration, lick1=self.lick1, lick2=self.lick2)  # , lick2 = self.lick2)
        plot = Plot(self.stream_events_data, padding=25, padding_bottom=0, padding_left=60,
                    index_mapper=self.stream_plot.index_mapper)
        plot.fixed_preferred_size = (100, 50)
        y_range = DataRange1D(low=0, high=3)
        plot.value_range = y_range
        plot.x_axis.orientation = "top"
        plot.x_axis.title = "Events"
        plot.x_axis.title_spacing = 5
        plot.x_axis.tick_generator = self.stream_plot.x_axis.tick_generator
        self.lick1 = [nan] * len(self.iteration)  # the last value is not nan so that the first incoming streaming value would be nan
        self.lick1[-1] = 0
        self.lick2 = [nan] * len(self.iteration)
        self.lick2[-1] = 0
        self.laser = [0] * len(self.iteration)
        event_plot = plot.plot(("iteration", "lick1"), name="Left Licks", color="red", line_width=5, render_style="hold")[0]
        # this may be broken
        plot.plot(("iteration", "lick2"), name="Right Licks", color="blue", line_width=5, render_style="hold")
        event_plot.overlays.append(rangeselector)
        # laser_plot.overlays.append(rangeselector)
        plot.legend.visible = True
        plot.legend.bgcolor = "transparent"
        plot.legend.align = 'ul'
        self.stream_events_data.set_data("lick1", self.lick1)
        self.stream_events_data.set_data("lick2", self.lick2)
        # TODO: make y axis static

        self.stream_event_plot = plot

        container.add(self.stream_plot)
        container.add(self.stream_event_plot)

        return container

    def _addtrialmask(self):
        # get the sniff plot and add a selection overlay ability to it
        # print "New Trial: ", self.trialstart, self.trialend, self._laststreamtick
        if 'Sniff' in self.stream_plot.plots.keys():
            sniff = self.stream_plot.plots['Sniff'][0]
            datasource = getattr(sniff, "index", None)
            data = self.iteration
            if self._laststreamtick - self.trialend >= self.STREAMSIZE:
                return
            elif self._laststreamtick - self.trialstart >= self.STREAMSIZE:
                start = data[0]
            else:
                start = data[-self._laststreamtick + self.trialstart - 1]
            end = data[-self._laststreamtick + self.trialend - 1]
            datasource.metadata['trials_mask'] += (start, end)
        return

    def __laststreamtick_changed(self):

        shift = self._laststreamtick - self._previousendtick
        self._previousendtick = self._laststreamtick

        streams = self.stream_definition()
        if streams == None:
            return
        if 'sniff' in streams.keys():
            # get the sniff plot and add update the selection overlay
            if 'Sniff' in self.stream_plot.plots.keys():
                sniff = self.stream_plot.plots['Sniff'][0]
                datasource = getattr(sniff, "index", None)
                mask = datasource.metadata['trials_mask']
                new_mask = []
                for index in range(len(mask)):
                    mask_point = mask[index] - shift / 1000.0
                    if mask_point < 0.001:
                        if index % 2 == 0:
                            new_mask.append(0.001)
                        else:
                            del new_mask[-1]
                    else:
                        new_mask.append(mask_point)
                datasource.metadata['trials_mask'] = new_mask
        return

    def _updatelaser(self, lasertime):
        self.laser[-(self._laststreamtick - lasertime)] = self.laser_amp
        self.stream_plot_data.set_data('laser', self.laser)
        return

    def _restart(self):

        self.trialNumber = 1
        self.rewards = 0

        self._righttrials = [1]
        self._lefttrials = [1]
        self.tick = [0]
        self.result = [0]
        # self.iteration = [0]
        # self.lick1 = [0]
        self._slwleftvals = []
        self._slwrightvals = []
        self._falselefts = 0
        self._falserights = 0
        self._corrights = 0
        self._corlefts = 0
        self._nomoves = 0
        self._bilicks = 0
        self._slwcrr = 0
        self._slwcrl = 0
        self._sameSideResponses = 0
        self._opposite_SideResponses = 0
        self._leftResponses = 0
        self._rightResponses = 0
        self._protocol_type_changed()
        #self.calculate_next_trial_parameters()
        self._windowResults = []

        time.clock()

        return

    def _mouse_changed(self):
        new_stamp = time_stamp()
        db = 'mouse' + str(self.mouse) + '_' + 'sess' + str(self.session) \
                    + '_' + new_stamp
        if self.db != db:
            self.db = db
        return

    def _fvTrigPhase_changed(self):
        if self.fvTrigPhase == "Exhalation onset":
            self.fvTrigPhaseVal = 1
        elif self.fvTrigPhase == "During exhalation":
            self.fvTrigPhaseVal = 0
        return

    def _protocol_type_changed(self):
        
        self.stimuli['Right'] = []
        self.stimuli['Left'] = []
        
        tempstim = LaserTrainStimulus(odorvalves = (),
                                                  flows = [(900, 100)],
                                                  laserstims = [],
                                                  id=1,
                                                  description = self.protocol_type,
                                                  num_lasers = 0,
                                                  numPulses = [],
                                                  pulseOffDuration = []
                                                  )
        
        self.interTrialIntervalSeconds = 2
        self.stimuli['Right'].append(tempstim)
        self.stimuli['Left'].append(tempstim)
        self.fvdur = 0
        if self.protocol_type == 'Blocks' or self.protocol_type == 'Alternate':
            self.trialtype = choice(['Left', 'Right'])
        elif self.protocol_type == 'Single port':
            self.trialtype = 'Left'


        if self.response_type =='treadmill':
            self.protocol_name = 'odor_id_treadmill_cw'

        self.currentstim = choice(self.stimuli[self.trialtype])

        print "---------- Stimuli changed ----------"
        for stimulus in self.stimuli.values():
            for stim in stimulus:
                print stim
        print "Grace Period:", self.lickgraceperiod
        print "Blocksize:", self.blocksize
        print "-------------------------------------"
        return

    def _session_changed(self):
        new_stamp = time_stamp()
        self.db = 'mouse' + str(self.mouse) + '_' + 'sess' + str(self.session) \
            + '_' + new_stamp


    def _callibrate(self):
        if self.start_label == "Start" and  self.cal_olfa_label == "Cal Olfa (ON)":
            do_after(2500, self._callibrate)

        self._fv_button_fired()

        return


#---------------------------------------------------------------------------------------------------------------------------
#--------------------------Button events------------------------------------------------------------------------------------
    def _start_button_fired(self):
        if self.monitor.running:
            self.start_label = 'Start'
            
            if self.fv_label == "Final Valve (ON)":
                self._fv_button_fired()
            self.session_timer.Stop()
            self.monitor.stop_acquisition()
            print "Unsynced trials: ", self._unsyncedtrials
            self.session += 1
        else:
            # self.session = self.session + 1
            if self.protocol_type == 'Please Select':
                print 'ERROR: Please select a protocol type to begin.'
                return
            if self.monitor.protocol_name != self.protocol_name:
                print "WARNING, ARDUINO PROTOCOL IS NOT: " + self.protocol_name
                print 'Please exit and upload correct sketch to arduino before starting.'
                return
            self.start_label = 'Stop'
            self._restart()
            # self._callibrate()
            new_stamp = time_stamp()
            self.elapsed_time_min = 0
            self.elapsed_time_sec = 0
            self.trial_time = 0
            self.session_timer = Timer(1000,self.timer_update_task)
            self.db = 'mouse' + str(self.mouse) + '_' + 'sess' + str(self.session) \
                + '_' + new_stamp
            self.monitor.database_file = 'C:/VoyeurData/' + self.db
            self.monitor.start_acquisition()
        return
    
    def timer_update_task(self):
        
        if self.elapsed_time_sec >= 59:
            self.elapsed_time_min += 1
            self.elapsed_time_sec = 0
        else:
            self.elapsed_time_sec += 1
        self.trial_time += 1


    def _pause_button_fired(self):
        if self.monitor.recording:
            self.monitor.pause_acquisition()
            self.pause_label = 'Unpause'
        else:
            self.pause_label = 'Pause'
            self.trialNumber += 1
            self.monitor.unpause_acquisition()
        return

    def _save_as_button_fired(self):
        dialog = FileDialog(action="save as")
        dialog.open()
        if dialog.return_code == OK:
            self.db = os.path.join(dialog.directory, dialog.filename)
        return
    
    def _waterdur_changed(self):
        self.save_water_params()
        return
    
    def _waterdur2_changed(self):
        self.save_water_params()
        return
    
    def save_water_params(self):
        
        configuration_obj = ConfigObj(self.config['configFilename'])
        
        if not hasattr(self, 'water_volume'):
            self.water_volume = 0.25
        water_vol_str = str(self.water_volume)+'ul'
        
        configuration_obj['rig_params']['water_durations']['valve_1_left'][water_vol_str] = self.waterdur
        configuration_obj['rig_params']['water_durations']['valve_2_right'][water_vol_str] = self.waterdur2
        configuration_obj.write()
                
        return

    def _fv_button_fired(self):
        if self.monitor.recording:
            self._pause_button_fired()
        if self.fv_label == "Final Valve (OFF)":
            self.monitor.send_command("fv on")
            self.fv_label = "Final Valve (ON)"
        elif self.fv_label == "Final Valve (ON)":
            self.monitor.send_command("fv off")
            self.fv_label = "Final Valve (OFF)"
        return
    
    
    def _water_button1_fired(self):
        command = "wv 1 " + str(self.waterdur)
        self.monitor.send_command(command)
        return

    def _water_button2_fired(self):
        command = "wv 2 " + str(self.waterdur2)
        self.monitor.send_command(command)
        return


    def _cal_button1_fired(self):
        if self.monitor.recording:
            self._pause_button_fired()
        command = 'callibrate 1 ' + str(self.waterdur)
        self.monitor.send_command(command)
        return

    def _cal_button2_fired(self):
        if self.monitor.recording:
            self._pause_button_fired()
        command = 'callibrate 2 ' + str(self.waterdur2)
        self.monitor.send_command(command)
        return

    def _clean_button_fired(self):
#         if self.monitor.recording:
#             self._pause_button_fired()
        if self.clean_label == "Clean (OFF)":
            self.monitor.send_command("clean on")
            self.clean_label = "Clean (ON)"
        elif self.clean_label == "Clean (ON)":
            self.monitor.send_command("clean off")
            self.clean_label = "Clean (OFF)"
        return
    
    def _laser_button_fired(self, new):
        laser = self.laser_select
        command = laser + " trigger " + \
            str(self.laser_amp) + " " + str(self.laser_dur)
        self.monitor.send_command(command)
        # self._protocol_type_changed()
        return


#---------------------------------------------------------------------------------------------------------------------------
#--------------------------Initialization------------------------------------------------------------------------------------
    def __init__(self, trialNumber,
                        mouse,
                        session,
                        stamp,
                        interTrialInterval,
                        trialtype,
                        max_rewards,
                        fvdur,
                        trialdur,
                        lickgraceperiod,
                        protocol_type,
                        laseramp,
                        lasergolatency,
                        laserTrigPhase,
                        stimindex=0,
                        **kwtraits):
        super(Lick2Afc, self).__init__(**kwtraits)
        self.laser_multi_sniff = 0 # when this is set to 1, trigtrain will look for the next inhale and retrigger itself.
        self.trialNumber = trialNumber
        self.stamp = stamp
        self.config = Voyeur_utilities.parse_rig_config() #get a configuration object with the default settings.
        self.rig = self.config['rigName']
        self.waterdur = self.config['waterValveDurations']['valve_1_left']['0.25ul']
        self.waterdur2 = self.config['waterValveDurations']['valve_2_right']['0.25ul']
        self.olfas = self.config['olfas']
        
        self.db = 'mouse' + str(mouse) + '_' + 'sess' + str(session) \
                    + '_' + self.stamp
        
        self.mouse = mouse
        self.session = session
        self.interTrialIntervalSeconds = interTrialInterval
        self.trialtype = trialtype
        self._next_trialtype = self.trialtype
        self.fvdur = fvdur
        self.trialdur = trialdur
        self.lickgraceperiod = lickgraceperiod
        self.blocksize = self.BLOCKSIZE
        self.laser_amp = laseramp
        self.lasergolatency = lasergolatency
        self._stimindex = stimindex
        self.rewards = 0
        self.protocol_type = protocol_type
        self._protocol_type_changed()
        self.protocol_name = 'LickTrainingV1'
        self._max_rewards = max_rewards

        #self.calculate_next_trial_parameters()

        time.clock()


        if self.ARDUINO:
            self.monitor = Monitor()
            print 'initializing monitor'
            self.monitor.protocol = self
            if self.monitor.protocol_name != self.protocol_name:
                print "WARNING, ARDUINO PROTOCOL IS NOT: " + self.protocol_name + 'PLEASE UPLOAD CORRECT SKETCH BEFORE STARTING'
            
        return

    def trial_parameters(self):
        """Returns a class of TrialParameters for the next trial"""
        

        if self.trialtype == "Right":
            trial_type = 1
        elif self.trialtype == "Left":
            trial_type = 0
        elif self.trialtype == "RightorLeft":
            trial_type = 2


        protocol_params = {
                        "mouse"         : self.mouse,
                        "rig"           : self.rig,
                        "session"       : self.session,
                        'response_type' : self.response_type
                        }

        if self.response_type == 'treadmill': 
            treadmill = 1    
        else: 
            treadmill = 0
        

        controller_dict = {
                           
                            "trialNumber"   : (1, db.Int, self.trialNumber),
                            "trialtype"     : (2, db.Int, trial_type),
                            "waterdur"      : (3, db.Int, self.waterdur),
                            "waterdur2"     : (4, db.Int, self.waterdur2),
                            "fvdur"         : (5, db.Int, self.fvdur),
                            "trialdur"      : (6, db.Int, self.trialdur),
                            "iti"           : (7, db.Int, self.interTrialIntervalSeconds * 1000),
                            "fvtrig_on_exh" : (8, db.Int, self.fvTrigPhaseVal),
                            "treadmill_response":(9, db.Int, treadmill),
                            'grace_period' : (10,db.Int, self.lickgraceperiod),
                            'rewards'       :(11,db.Int, self.rewards)
                            }

        # print controller_dict

        return TrialParameters(
                    protocolParams=protocol_params,
                    controllerParams=controller_dict
                )

    def protocol_parameters_definition(self):
        """Returns a dictionary of {name => db.type} defining protocol parameters"""

        params_def = {
            "mouse"         : db.Int,
            "rig"           : db.String32,
            "session"       : db.Int,
            'response_type' : db.String32,
        }


        return params_def

    def controller_parameters_definition(self):
        """Returns a dictionary of {name => db.type} defining controller parameters"""

        params_def = {
            "trialNumber"    : db.Int,
            "trialtype"      : db.Int,
            "waterdur"       : db.Int,
            "waterdur2"      : db.Int,
            "fvdur"          : db.Int,
            "trialdur"       : db.Int,
            "iti"            : db.Int,
            "fvtrig_on_exh"  : db.Int,
            'treadmill_response' :db.Int,
            'grace_period'  : db.Int,
            'rewards'       : db.Int
        }

        return params_def

    def event_definition(self):
        """Returns a dictionary of {name => (index,db.Type} of event parameters for this protocol"""

        return {
            "result"         : (1, db.Int),
            "paramsgottime"  : (2, db.Int),
            "starttrial"     : (3, db.Int),
            "endtrial"       : (4, db.Int),
            "no_sniff"       : (5, db.Int),
            "fvOnTime"       : (6, db.Int)
        }

    def stream_definition(self):
        """Returns a dictionary of {name => (index,db.Type,Arduino type)} of streaming data parameters for this protocol
        This is not called until the monitor is started and the stream is requested. It does not setup the monitor before start."""
        
        if self.response_type == 'treadmill':
            stream_def = {
                          "packet_sent_time" : (1, 'unsigned long', db.Int),
                          "sniff_samples"    : (2, 'unsigned int', db.Int),
                          "sniff"            : (3, 'int', db.FloatArray,),
    #                     "sniff_ttl"        : (4, db.FloatArray,'unsigned long'),
                          "lick1"            : (4, 'unsigned long', db.FloatArray),
                          "lick2"            : (5, 'unsigned long', db.FloatArray),
                          "treadmill"        : (6, 'int', db.FloatArray,)
                          }
        
        else:
            stream_def = {
                          "packet_sent_time" : (1, 'unsigned long', db.Int),
                          "sniff_samples"    : (2, 'unsigned int', db.Int),
                          "sniff"            : (3, 'int', db.FloatArray,),
#                         "sniff_ttl"        : (4, db.FloatArray,'unsigned long'),
                          "lick1"            : (4, 'unsigned long', db.FloatArray),
                          "lick2"            : (5, 'unsigned long', db.FloatArray)
                          }
        
        return stream_def

    def process_event_request(self, event):
        """
        Process event requested from controller.
        """
        self.timestamp("end")
        self.paramsgottime = int(event['paramsgottime'])
        self.trialstart = int(event['starttrial'])
        self.trialend = int(event['endtrial'])
        result = int(event['result'])  # 1 is right, 2 is left, 3 left 4 right
        # update trials mask
        if self.trialend > self._laststreamtick:
            self._shiftlicks(self.trialend - self._laststreamtick)
            self._laststreamtick = self.trialend

        self._addtrialmask()
        

        if self.result[-1] == 1 or self.result[-1] == 2:
            self.rewards += 1
        if self.rewards >= self._max_rewards and self.start_label == 'Stop':
                self._start_button_fired()

        self.result = append(self.result, int(event['result']))
        return






    def process_stream_request(self, stream):
        """
        Process stream requested from controller.
        """
        
        if stream:
            # newtime = time.clock()
            num_sniffs = stream['sniff_samples']
            packet_sent_time = stream['packet_sent_time']

            # print "Num sniffs:", num_sniffs

            # TODO: Decouple sniff and treadmill
            if packet_sent_time > self._laststreamtick + num_sniffs:
                lostsniffsamples = packet_sent_time - self._laststreamtick - num_sniffs
                print "lost sniff:", lostsniffsamples
                if lostsniffsamples > self.STREAMSIZE:
                    lostsniffsamples = self.STREAMSIZE
                lostsniffsamples = int(lostsniffsamples)
                # pad sniff signal with last value for the lost samples first then append received sniff signal
                new_sniff = hstack((self.sniff[-self.STREAMSIZE + lostsniffsamples:], [self.sniff[-1]] * lostsniffsamples))
                if stream['sniff'] is not None:
                    self.sniff = hstack((new_sniff[-self.STREAMSIZE + num_sniffs:],
                                         negative(stream['sniff'] * (2.44140625*self.sniff_scale))))
            else:
                if stream['sniff'] is not None:
                    new_sniff = hstack((self.sniff[-self.STREAMSIZE + num_sniffs:],
                                        negative(stream['sniff'] * (2.44140625*self.sniff_scale))))
                    self.sniff = new_sniff

            self.stream_plot_data.set_data("sniff", self.sniff)

            
            if 'treadmill' in stream.keys() and stream['treadmill'] is not None: # and is short circuit here and shouldn't error if no 'treadmill' key in dict.
                if packet_sent_time > self._laststreamtick + num_sniffs:
                    new_treadmill = hstack((self.treadmill[-self.STREAMSIZE+lostsniffsamples:], [self.treadmill[-1]]*lostsniffsamples))
                    self.treadmill = hstack((new_treadmill[-self.STREAMSIZE+num_sniffs:], stream['treadmill']-1000))
                else:
                    new_treadmill = hstack((self.treadmill[-self.STREAMSIZE+num_sniffs:], stream['treadmill']-1000))
                    self.treadmill = new_treadmill
                self.stream_plot_data.set_data("treadmill", self.treadmill)
                
                

            if stream['lick1'] is not None or (self._laststreamtick - self._lastlickstamp < self.STREAMSIZE) or stream['lick2'] is not None:
                [self.lick1, self.lick2] = self._process_licks(stream, ('lick1', 'lick2'), [self.lick1, self.lick2])
                # [self.lick1] = self._process_licks(stream, ('lick1',), [self.lick1])

            if "laserontime" in self.event_definition().keys():
                lasershift = int(packet_sent_time - self._laststreamtick)
                if lasershift > self.STREAMSIZE:
                    lasershift = self.STREAMSIZE
                new_laser = hstack((self.laser[-self.STREAMSIZE + lasershift:], [0] * lasershift))
                self.laser = new_laser
                self.stream_plot_data.set_data('laser', self.laser)

            self._laststreamtick = packet_sent_time


        return



    def _process_licks(self, stream, licksignals, lickarrays):

        packet_sent_time = stream['packet_sent_time']

        # TODO: find max shift first, apply it to all licks
        maxtimestamp = int(packet_sent_time)
        for i in range(len(lickarrays)):
            licksignal = licksignals[i]
            if licksignal in stream.keys():
                streamsignal = stream[licksignal]
                if streamsignal is not None and streamsignal[-1] > maxtimestamp:
                        maxtimestamp = streamsignal[-1]
                        print "**************************************************************"
                        print "WARNING! Lick timestamp exceeds timestamp of received packet: "
                        print "Packet sent timestamp: ", packet_sent_time, "Lick timestamp: ", streamsignal[-1]
                        print "**************************************************************"
        maxshift = int(packet_sent_time - self._laststreamtick)
        if maxshift > self.STREAMSIZE:
            maxshift = self.STREAMSIZE - 1

        for i in range(len(lickarrays)):

            licksignal = licksignals[i]
            lickarray = lickarrays[i]

            if licksignal in stream.keys():
                if stream[licksignal] is None:
                    lickarray = hstack((lickarray[-self.STREAMSIZE + maxshift:], [lickarray[-1]] * maxshift))
                else:
                    # print "licks: ", stream['lick'], "\tnum sniffs: ", currentshift
                    last_state = lickarray[-1]
                    last_lick_tick = self._laststreamtick
                    for lick in stream[licksignal]:
                        # print "last lick tick: ", last_lick_tick, "\tlast state: ", last_state
#                        if lick == 0:
#                            continue
                        shift = int(lick - last_lick_tick)
                        if shift <= 0:
                            if shift < self.STREAMSIZE * -1:
                                shift = -self.STREAMSIZE + 1
                            if isnan(last_state):
                                lickarray[shift - 1:] = [i + 1] * (-shift + 1)
                            else:
                                lickarray[shift - 1:] = [nan] * (-shift + 1)
                        # Lick timestamp exceeds packet sent time. Just change the signal state but don't shift
                        elif lick > packet_sent_time:
                            if isnan(last_state):
                                lickarray[-1] = i + 1
                            else:
                                lickarray[-1] = nan
                        else:
                            if shift > self.STREAMSIZE:
                                shift = self.STREAMSIZE - 1
                            lickarray = hstack((lickarray[-self.STREAMSIZE + shift:], [lickarray[-1]] * shift))
                            if isnan(last_state):
                                lickarray = hstack((lickarray[-self.STREAMSIZE + 1:], [i + 1]))
                            else:
                                lickarray = hstack((lickarray[-self.STREAMSIZE + 1:], [nan]))
                            last_lick_tick = lick
                        last_state = lickarray[-1]
                        # last timestamp of lick signal change
                        self._lastlickstamp = lick
                    lastshift = int(packet_sent_time - last_lick_tick)
                    if lastshift >= self.STREAMSIZE:
                        lastshift = self.STREAMSIZE
                        lickarray = [lickarray[-1]] * lastshift
                    elif lastshift > 0 and len(lickarray) > 0:
                        lickarray = hstack((lickarray[-self.STREAMSIZE + lastshift:], [lickarray[-1]] * lastshift))
                if len(lickarray) > 0:
                    self.stream_events_data.set_data(licksignal, lickarray)
                    # self.stream_event_plot.request_redraw()
                    lickarrays[i] = lickarray

        return lickarrays

    def _shiftlicks(self, shift):

        if shift > self.STREAMSIZE:
            shift = self.STREAMSIZE - 1

        streamdef = self.stream_definition()
        if 'lick1' in streamdef.keys():
            self.lick1 = hstack((self.lick1[-self.STREAMSIZE + shift:], self.lick1[-1] * shift))
            self.stream_events_data.set_data('lick1', self.lick1)
        if 'lick2' in streamdef.keys():
            self.lick2 = hstack((self.lick2[-self.STREAMSIZE + shift:], self.lick2[-1] * shift))
            self.stream_events_data.set_data('lick2', self.lick2)
        return

    def start_of_trial(self):

        self.timestamp("start")
        print "***** Trial: ", self.trialNumber, "\tStimulus: ", self.currentstim, " *****"




    def end_of_trial(self):

        self.trialNumber +=1 
        self._last_trialtype = self.trialtype
        self.calculate_next_trial_parameters()
        self.trial_time = 0



    def calculate_next_trial_parameters(self):

        # TODO: permute trials in blocks (see laser_go_nogo_timing
        if self.protocol_type == 'Blocks':
            if not hasattr(self, 'block_count'):
                self.block_count = 0;
            self.block_count += 1
            if self.block_count > self.blocksize:
                self.block_count = 0
                if self.trialtype == 'Left':
                    self.trialtype = 'Right'
                else:
                    self.trialtype = 'Left'
        
        elif self.protocol_type == 'Alternate':
            if self.trialtype == 'Right':
                self.trialtype = 'Left'
            else:
                self.trialtype = 'Right'
                
        self.currentstim = self.stimuli[self.trialtype][0]


        return

    def trial_iti_milliseconds(self):
        return 0

    def timestamp(self, when):
        """ Used to timestamp events """
        if(when == "start"):
            self._paramsenttime = time.clock()
            # print "start timestamp ", self._paramsenttime
        elif(when == "end"):
            self._resultstime = time.clock()




if __name__ == '__main__':

    # arduino parameter defaults


    trialNumber = 1
    trialtype = "Right"
    fvdur = 0
    trialdur = 1000000
    lickgraceperiod = 0
    stimindex = 0
    laseramp = 1500
    lasergolatency = 100
    laserTrigPhase = "Inhalation"
    protocol_type = "Please Select"  # "LaserTraining"
    max_rewards = 400


    # protocol parameter defaults
    mouse = 434  # can I make this an illegal value so that it forces me to change it????

    session = 18
    stamp = time_stamp()
    interTrialInterval = 8
    stimindex = 0

    # protocol
    protocol = Lick2Afc(trialNumber,
                    mouse,
                    session,
                    stamp,
                    interTrialInterval,
                    trialtype,
                    max_rewards,
                    fvdur,
                    trialdur,
                    lickgraceperiod,
                    protocol_type,
                    laseramp,
                    lasergolatency,
                    laserTrigPhase,
                    stimindex,
                    )

    # GUI
    protocol.configure_traits()

